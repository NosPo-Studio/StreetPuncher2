local global = ...
return function(args)
    return global.core.GameObject.new(args)
end