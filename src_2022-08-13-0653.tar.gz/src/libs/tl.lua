local t = {t = 1}

print("t")

return t