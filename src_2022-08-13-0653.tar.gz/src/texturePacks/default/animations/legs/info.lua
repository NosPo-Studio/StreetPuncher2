local info = {
	format = "pan",
	version = "v0.1",
	frameTime = .1,
}

return info