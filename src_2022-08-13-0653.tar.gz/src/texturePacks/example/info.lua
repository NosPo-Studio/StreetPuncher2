local info = {
	useBufferWhitelist = false,
	
	bufferBlacklist = {
		["debug_blacklist"] = true,
		["human"] = true,
	},
	
	bufferWhitelist = {
		
	},
}

return info